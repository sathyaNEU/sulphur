# MML group meeting, Thursday 5 November 2026

Present: Helene, Magne, Tor. Apologies: Ragnhild (at sea until the 12th).

## 1. NSSMP 2027 training slots

Proposals are due Friday 20 November at noon. Helene went through the call text again:

- Each team gets one reserved slot of up to 120 hours on the programme's GPU node in February. The proposal names one
  training configuration for it. It is trained once, with the recipe the proposal states, and the programme scores
  the final checkpoint on the verified benchmark: mean log loss over the 20,000 grab-sample points.
- The form asks for the expected benchmark log loss of that final checkpoint and a range we expect the result to fall
  in four times out of five. Teams are ranked on the expected value, and a team whose result lands outside its own
  range drops a place in the 2028 ranking.
- Our pilot quota of 32 benchmark uploads ran out on 23 October. Nothing more can be scored before the slots are
  awarded.

We keep our standard recipe for the slot: batch 128, twelve epochs, cosine schedule with 3 per cent warm-up, the final
checkpoint, no early stopping.

## 2. Shortlist

Agreed to choose among four configurations. All fit the slot on Tor's timings (shortlist sheet).

| Opt. | Width | Labels | LR |
|---|---|---|---|
| A | 1024 | 128,000 expert | to be set |
| B | 512 | 128,000 expert + 128,000 contractor | 5e-4 |
| C | 256 | 128,000 expert + 128,000 contractor + 1,024,000 map transfer | 1e-3 |
| D | 256 | 128,000 expert + 1,024,000 map transfer | 1e-3 |

- Lyngvær's lot 1 (128,000 points) came in the week of 19 October and is all the contractor labelling in this
  year's budget. Lots 2 to 4 are not funded.
- Map-transfer shards are prepared for all 1,024,000 points (Tor, end of August).
- The 1024-wide job in week 43 ran out of walltime at about 70 per cent of its schedule, so option A still needs a
  learning rate.
- B, C and D use the rates we took for 512 and 256 after the week 42 check.

## 3. Actions

- Magne: expected benchmark loss and range for all four options, and which one to name, to Helene by Tuesday 10
  November.
- Tor: exports from the tracking server, the scheduler and the checkpoint store into the shared folder (done 4
  November).
- Helene: proposal text once Magne's figures are in.

## 4. Other business

- Ragnhild's September transects from Nordkappbanken will not be interpreted before January, so they are not in any
  option.
- Tor will ask IT about the scratch quota again. One item dump was lost to it in week 42.
