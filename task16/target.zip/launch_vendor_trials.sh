#!/bin/bash
# vendor label trials, week 44
# usage: bash launch_vendor_trials.sh
set -euo pipefail

PART=gpu-preempt
submit () { sbatch -p "$PART" --gres=gpu:1 -t 24:00:00 -J "$1" train.sbatch "${@:2}"; sleep 3; }

submit vend-w128-exp128k-map384k-s3 --width 128 --lr 2e-3 --exp 0-31 --map 0-95 --seed 3
submit vend-w128-exp32k-map32k-s3 --width 128 --lr 2e-3 --exp 0-7 --map 0-7 --seed 3
submit vend-w128-exp32k-map224k-s3 --width 128 --lr 2e-3 --exp 0-7 --map 0-55 --seed 3
submit vend-w128-exp64k-map192k-s3 --width 128 --lr 2e-3 --exp 0-15 --map 0-47 --seed 3
submit vend-w128-exp128k-map384k-s1 --width 128 --lr 2e-3 --exp 0-31 --map 0-95 --seed 1
submit vend-w128-exp64k-ctr64k-s2 --width 128 --lr 2e-3 --exp 0-15 --ctr 0-15 --seed 2
submit vend-w128-exp128k-ctr128k-s1 --width 128 --lr 2e-3 --exp 0-31 --ctr 0-31 --seed 1
submit vend-w128-exp128k-ctr128k-s3 --width 128 --lr 2e-3 --exp 0-31 --ctr 0-31 --seed 3
submit vend-w128-exp32k-ctr96k-s3 --width 128 --lr 2e-3 --exp 0-7 --ctr 0-23 --seed 3
submit vend-w128-exp64k-ctr64k-s3 --width 128 --lr 2e-3 --exp 0-15 --ctr 0-15 --seed 3
submit vend-w128-exp64k-map64k-s1 --width 128 --lr 2e-2 --exp 0-15 --map 0-15 --seed 1
submit vend-w128-exp128k-ctr128k-s2 --width 128 --lr 2e-3 --exp 0-31 --ctr 0-31 --seed 2
submit vend-w128-exp64k-map192k-s1 --width 128 --lr 2e-3 --exp 0-15 --map 0-47 --seed 1
submit vend-w128-exp32k-map32k-s2 --width 128 --lr 2e-3 --exp 0-7 --map 0-7 --seed 2
submit vend-w128-exp128k-map128k-s2 --width 128 --lr 2e-3 --exp 0-31 --map 0-31 --seed 2
submit vend-w128-exp32k-map96k-s1 --width 128 --lr 2e-3 --exp 0-7 --map 0-23 --seed 1
submit vend-w128-exp64k-map64k-s2 --width 128 --lr 2e-3 --exp 0-15 --map 0-15 --seed 2
submit vend-w128-exp64k-map64k-s3 --width 128 --lr 2e-3 --exp 0-15 --map 0-15 --seed 3
submit vend-w128-exp32k-map32k-s1 --width 128 --lr 2e-3 --exp 0-7 --map 0-7 --seed 1
submit vend-w128-exp128k-map384k-s2 --width 128 --lr 2e-3 --exp 0-31 --map 0-95 --seed 2
submit vend-w128-exp32k-ctr32k-s1 --width 128 --lr 2e-3 --exp 0-7 --ctr 0-7 --seed 1
submit vend-w128-exp32k-ctr32k-s3 --width 128 --lr 2e-3 --exp 0-7 --ctr 0-7 --seed 3
submit vend-w128-exp32k-map224k-s1 --width 128 --lr 2e-3 --exp 0-7 --map 0-55 --seed 1
submit vend-w128-exp32k-ctr32k-s2 --width 128 --lr 2e-3 --exp 0-7 --ctr 0-7 --seed 2
submit vend-w128-exp32k-ctr96k-s1 --width 128 --lr 2e-3 --exp 0-7 --ctr 0-23 --seed 1
submit vend-w128-exp64k-map448k-s1 --width 128 --lr 2e-3 --exp 0-15 --map 0-111 --seed 1
submit vend-w128-exp32k-map224k-s2 --width 128 --lr 2e-3 --exp 0-7 --map 0-55 --seed 2
submit vend-w128-exp32k-map96k-s2 --width 128 --lr 2e-3 --exp 0-7 --map 0-23 --seed 2
submit vend-w128-exp64k-ctr64k-s1 --width 128 --lr 2e-3 --exp 0-15 --ctr 0-15 --seed 1
submit vend-w128-exp64k-map448k-s2 --width 128 --lr 2e-3 --exp 0-15 --map 0-111 --seed 2
submit vend-w128-exp32k-ctr96k-s2 --width 128 --lr 2e-3 --exp 0-7 --ctr 0-23 --seed 2
submit vend-w128-exp32k-map96k-s3 --width 128 --lr 2e-3 --exp 0-7 --map 0-23 --seed 3
submit vend-w128-exp64k-map192k-s2 --width 128 --lr 2e-3 --exp 0-15 --map 0-47 --seed 2
submit vend-w128-exp128k-map128k-s3 --width 128 --lr 2e-3 --exp 0-31 --map 0-31 --seed 3
submit vend-w128-exp128k-map128k-s1 --width 128 --lr 2e-3 --exp 0-31 --map 0-31 --seed 1
submit vend-w128-exp64k-map448k-s3 --width 128 --lr 2e-3 --exp 0-15 --map 0-111 --seed 3
