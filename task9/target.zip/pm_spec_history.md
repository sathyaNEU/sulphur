# ILD-CMP preventive maintenance specification: revision history

Owner: Victor Kelley (CMP module engineering). Applies to polish units PU-1 to PU-4, ILD-CMP step.

| Rev | Effective | Full PM interval | Full PM scope | Pad change |
|---|---|---|---|---|
| D | 2025-02-17 | 1,800 wafers | polishing pad, conditioner disk, retaining ring; platen and carrier inspection | every 600 wafers +/- 50 |
| E | 2025-09-08 | 2,000 wafers | as Rev D | every 600 wafers +/- 50 |
| F | 2026-04-02 | 2,800 wafers | as Rev D | every 600 wafers +/- 50 |

Intervals count wafers polished on the unit since its last full PM. Rev F extends the interval on the pad supplier's
extended-life data (ECN-4471, approved by the module review on 2026-03-26).

Unscheduled part changes (a damaged conditioner disk, a chipped or worn retaining ring) are made as found and entered
in the unit's maintenance log; they do not restart the full PM count.

## Rev G (draft for the September module review)

Status: draft; bracketed items stay open until YE-2026-031 closes.

| Rev | Effective | Full PM interval | Full PM scope | Pad change | Own count |
|---|---|---|---|---|---|
| G (draft) | [after review] | 2,800 wafers | as Rev D less [part] | every 600 wafers +/- 50 | [part]: every [N] wafers since it was last replaced, [N] set per unit |

The part responsible for the edge ring comes out of the full PM scope and is changed on its own count; the excursion
review names the part and sets each unit's count.

## Engineering waiver EW-118

Raised by Leah Griffith on 2026-05-29. Approved for 2026-06-01 to 2026-08-14.

Trial of conditioner disk life past the full PM interval. At full PMs on PU-1 to PU-4 during the waiver period the
installed conditioner disk may be retained if it passes visual inspection, for at most two full PMs in total. Pad and
retaining ring are replaced as normal. The technician records the retained disk in the PM entry.
