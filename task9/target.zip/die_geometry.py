"""Fab 2 yield database: die position helpers (sort map conventions, rev 3).

Die (col, row) indices are counted from the wafer centre; col 0 / row 0 is the die whose lower-left corner sits at the
centre. Positions are in millimetres on a 300 mm wafer. Zones are radial bands of the die centre, numbered from the
centre outwards.
"""
import math

ZONE_EDGES_MM = [0, 40, 62, 80, 95, 108, 120, 136, 147]


def die_center(col, row, die_w_mm, die_h_mm, x_offset_mm=0.0, y_offset_mm=0.0):
    """Centre of die (col, row) in wafer coordinates (mm)."""
    return (col + 0.5) * die_w_mm + x_offset_mm, (row + 0.5) * die_h_mm + y_offset_mm


def die_radius(col, row, die_w_mm, die_h_mm, x_offset_mm=0.0, y_offset_mm=0.0):
    x, y = die_center(col, row, die_w_mm, die_h_mm, x_offset_mm, y_offset_mm)
    return math.hypot(x, y)


def zone_of(radius_mm):
    """Sort zone 1 to 8 for a die centre at this radius."""
    for k in range(1, len(ZONE_EDGES_MM)):
        if radius_mm < ZONE_EDGES_MM[k]:
            return k
    return len(ZONE_EDGES_MM) - 1
